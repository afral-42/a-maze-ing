import random

import numpy as np
from numpy.typing import NDArray

from mazegen.generator.abstract_grid_generator import AbstractMazeGridGenerator
from mazegen.generator.maze_initializer import MazeInitializer
from mazegen.models.direction import DX, DY, OPPOSITE, Direction
from mazegen.models.maze_settings import MazeSettings


class RecursiveBacktrackingGenerator(AbstractMazeGridGenerator):
    def __init__(
        self,
        settings: MazeSettings,
        initializer: MazeInitializer,
    ) -> None:
        super().__init__(settings, initializer)

    def generate(self) -> NDArray[np.int8]:
        grid = self._initializer.init_maze()
        self._carve_passages_from(
            self._settings.entry[0], self._settings.entry[1], grid
        )
        return grid

    def _carve_passages_from(
        self, x: int, y: int, grid: NDArray[np.int8]
    ) -> None:
        directions = random.sample(list(Direction), k=len(Direction))
        for d in directions:
            nx, ny = x + DX[d], y + DY[d]
            if (
                0 <= ny < self._settings.height
                and 0 <= nx < self._settings.width
                and grid[ny][nx] == 15
            ):
                self._build_steps.append((x, y, d))
                grid[y][x] &= ~d
                grid[ny][nx] &= ~(OPPOSITE[d])
                self._carve_passages_from(nx, ny, grid)
